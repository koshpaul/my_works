package com.example.pl.gps;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LocationManager LocationManager;

    Double Latitude, Longitude;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);


            LocationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        }

        @Override
        protected void onResume() {
            super.onResume();
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            {
                    LocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                            0, 0, locationListener);
                    LocationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER, 4000, 10, locationListener);
            }
            checkEnabled();
        }

        private LocationListener locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(Location location) {
                Latitude = location.getLatitude();
                Longitude = location.getLongitude();
            }

           @Override
           public void onProviderDisabled(String provider) {
                checkEnabled();
           }

            @Override
            public void onProviderEnabled(String provider) {
                checkEnabled();
            }

           @Override
           public void onStatusChanged(String provider, int status, Bundle extras) {

           }
        };

        private void checkEnabled() {
                   LocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                   LocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
       }
}